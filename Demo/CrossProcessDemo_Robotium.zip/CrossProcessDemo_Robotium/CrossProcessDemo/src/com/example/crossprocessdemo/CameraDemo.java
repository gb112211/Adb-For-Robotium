package com.example.crossprocessdemo;

import java.io.File;

import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class CameraDemo extends Activity {

	String mPhotoPath;
	public final static int CAMERA_RESULT = 8888;
	ImageView iv;
	Button camBtn;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_camera_demo);
		camBtn = (Button)findViewById(R.id.button1);
		iv = (ImageView)findViewById(R.id.imageView1);
		
		camBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.setAction("android.media.action.IMAGE_CAPTURE");
				intent.addCategory("android.intent.category.DEFAULT");
				mPhotoPath = "/sdcard/" + String.valueOf(System.currentTimeMillis()) + ".jpg";
				File file = new File(mPhotoPath);
				Uri uri = Uri.fromFile(file);
				intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
				startActivityForResult(intent, CAMERA_RESULT);
			}
		});
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data){
		if (requestCode == CAMERA_RESULT){
			Bitmap bitmap = BitmapFactory.decodeFile(mPhotoPath, null);
			iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
			iv.setImageBitmap(bitmap);
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	
}