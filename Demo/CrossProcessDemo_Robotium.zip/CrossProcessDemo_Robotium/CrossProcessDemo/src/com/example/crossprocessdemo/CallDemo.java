package com.example.crossprocessdemo;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.app.Activity;
import android.content.Intent;

public class CallDemo extends Activity {

	Button callBtn;
	EditText callNumber;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_call_demo);
		callBtn = (Button)findViewById(R.id.call);
		callNumber = (EditText)findViewById(R.id.number);
		
		callBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String number = callNumber.getText().toString();
				if (!number.equals("")){
					Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + number));
					startActivity(intent);
				}
			}
		});
	}

}
