package com.example.crossprocessdemo.test;

import java.io.IOException;

import xuxu.autotest.AdbDevice;
import xuxu.autotest.AndroidKeyCode;
import xuxu.autotest.element.Position;

import com.example.crossprocessdemo.MainActivity;
import com.robotium.solo.Solo;

import android.app.Activity;
import android.test.ActivityInstrumentationTestCase2;
import android.widget.EditText;

public class CrossProcessTests extends
		ActivityInstrumentationTestCase2<MainActivity> {
	
	private Solo solo;
	private Activity activity;
	
	public CrossProcessTests(){
		super(MainActivity.class);
	}

	public void setUp(){
		activity = getActivity();
		solo = new Solo(getInstrumentation(), activity);
	}
	
	public void tearDown(){
		solo.finishOpenedActivities();
	}
	
	public void testCamera() throws IOException, InterruptedException{
		solo.clickOnButton("拍照片");
		solo.clickOnButton("拍张照片");
		Thread.sleep(3000);
		
		Position position = new Position();
		AdbDevice adb = new AdbDevice();
		//点击拍照按钮
		adb.tap(position.findElementById("com.android.camera:id/shutter_button"));
		Thread.sleep(3000);
		//点击确定按钮
		adb.tap(position.findElementById("com.android.camera:id/btn_done"));
		Thread.sleep(3000);
		//按Home键返回桌面
		adb.sendKeyEvent(AndroidKeyCode.HOME);
		Thread.sleep(3000);
	}
	
}
